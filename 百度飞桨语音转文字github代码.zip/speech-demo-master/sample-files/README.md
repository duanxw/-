# 官方示例音频文件

16k 表示采样率 16000 


pcm/wav/amr/m4a后缀表示文件格式，其中amr为压缩格式。

amr按照 bit rates格式压缩，如 16k-23850.amr，表示 bit rates= 23850


详细转换方式请见http://ai.baidu.com/docs#/ASR-Tool-convert/top
